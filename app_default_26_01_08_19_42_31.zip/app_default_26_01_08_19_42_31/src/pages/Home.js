import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css';

function Home() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      const splashScreen = document.querySelector('.splash-screen');
      if (splashScreen) {
        splashScreen.style.opacity = '0';
        setTimeout(() => {
          const content = document.querySelector('.home-content');
          if (content) content.style.display = 'flex';
        }, 500);
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="home-page">
      <div className="splash-screen">
        <div className="splash-logo">
          <h1>ROBLOX LIKE</h1>
          <p>Loading game platform...</p>
          <div className="spinner"></div>
        </div>
      </div>

      <div className="home-content" style={{ display: 'none' }}>
        <header className="home-header">
          <div className="header-content">
            <h1 className="title">ROBLOX LIKE</h1>
            <p className="subtitle">Multiplayer Game Platform</p>
          </div>
        </header>

        <main className="home-main">
          <section className="hero">
            <div className="hero-content">
              <h2>Welcome to the Ultimate Gaming Platform</h2>
              <p>Play, create, and connect with millions of players around the world</p>
              <button className="button play-button" onClick={() => navigate('/game-selector')}>
                Play Now
              </button>
            </div>
          </section>

          <section className="features">
            <h2>Featured Game Modes</h2>
            <div className="features-grid">
              <div className="feature-card">
                <div className="feature-icon">💰</div>
                <h3>Idle Simulator</h3>
                <p>Earn currency, upgrade abilities, and reach the prestige system</p>
              </div>
              <div className="feature-card">
                <div className="feature-icon">🏎️</div>
                <h3>Racing</h3>
                <p>Race against players on exciting tracks with car upgrades</p>
              </div>
              <div className="feature-card">
                <div className="feature-icon">🧗</div>
                <h3>Obstacle Course</h3>
                <p>Complete challenging parkour courses and beat the leaderboard</p>
              </div>
              <div className="feature-card">
                <div className="feature-icon">⚔️</div>
                <h3>PvP Arena</h3>
                <p>Battle other players and climb the ranked competitive ladder</p>
              </div>
            </div>
          </section>

          <section className="info-section">
            <div className="info-card">
              <h3>Multiplayer Experience</h3>
              <p>Join rooms with other players, chat in real-time, and collaborate in team-based games</p>
            </div>
            <div className="info-card">
              <h3>Persistent Progress</h3>
              <p>Your game progress is saved automatically across all game modes</p>
            </div>
            <div className="info-card">
              <h3>Compete & Rank</h3>
              <p>Climb leaderboards, earn achievements, and become a champion</p>
            </div>
          </section>
        </main>

        <footer className="home-footer">
          <p>&copy; 2024 Roblox Like. All rights reserved.</p>
        </footer>
      </div>
    </div>
  );
}

export default Home;
