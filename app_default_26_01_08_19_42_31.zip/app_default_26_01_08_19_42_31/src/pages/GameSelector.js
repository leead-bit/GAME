import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './GameSelector.css';

function GameSelector({ context }) {
  const navigate = useNavigate();
  const [gameModes, setGameModes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedMode, setSelectedMode] = useState(null);
  const [showNameInput, setShowNameInput] = useState(false);
  const [playerName, setPlayerName] = useState(context.playerName);

  useEffect(() => {
    fetchGameModes();
  }, []);

  const fetchGameModes = async () => {
    try {
      setLoading(true);
      const response = await axios.get('http://localhost:5000/api/game-modes');
      setGameModes(response.data.modes);
      setError(null);
    } catch (err) {
      setError('Failed to load game modes. Please ensure the server is running.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handlePlayGame = (gameMode) => {
    if (!context.socket || !context.socket.connected) {
      setError('Not connected to server. Please try again.');
      return;
    }

    context.setPlayerName(playerName);

    context.socket.emit('join-game', {
      gameMode: gameMode.id,
      playerName: playerName
    });

    context.socket.once('join-success', (data) => {
      navigate(`/lobby/${gameMode.id}/${data.roomId}`);
    });
  };

  if (loading) {
    return (
      <div className="game-selector-page">
        <div className="loading">Loading game modes...</div>
      </div>
    );
  }

  return (
    <div className="game-selector-page">
      <header className="selector-header">
        <h1>Select a Game Mode</h1>
        <p>Choose your favorite game and jump into the action</p>
      </header>

      <div className="selector-content">
        {error && <div className="error">{error}</div>}

        <div className="player-info-card">
          <div className="player-info-content">
            <h3>Welcome, {context.playerName}!</h3>
            <button 
              className="button secondary" 
              onClick={() => setShowNameInput(!showNameInput)}
            >
              {showNameInput ? 'Close' : 'Change Name'}
            </button>
            {showNameInput && (
              <div className="name-input-group">
                <input
                  type="text"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  placeholder="Enter your player name"
                  maxLength="20"
                />
                <button 
                  className="button"
                  onClick={() => {
                    context.setPlayerName(playerName);
                    setShowNameInput(false);
                  }}
                >
                  Save Name
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="games-grid">
          {gameModes.map((mode) => (
            <div key={mode.id} className="game-card">
              <div className="game-card-header">
                <h2>{mode.name}</h2>
                <span className="game-badge">{mode.id}</span>
              </div>
              <p className="game-description">{mode.description}</p>
              <div className="game-stats">
                <div className="stat">
                  <span className="stat-label">Players Online:</span>
                  <span className="stat-value">{mode.players}</span>
                </div>
                <div className="stat">
                  <span className="stat-label">Max Players:</span>
                  <span className="stat-value">{mode.maxPlayers}</span>
                </div>
              </div>
              <button
                className="button play-button"
                onClick={() => handlePlayGame(mode)}
              >
                Play {mode.name}
              </button>
            </div>
          ))}
        </div>
      </div>

      <footer className="selector-footer">
        <button className="button secondary" onClick={() => navigate('/')}>
          Back to Home
        </button>
      </footer>
    </div>
  );
}

export default GameSelector;
