import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './Lobby.css';

function Lobby({ context }) {
  const { gameMode, roomId } = useParams();
  const navigate = useNavigate();
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [readyStatus, setReadyStatus] = useState(false);
  const [startingGame, setStartingGame] = useState(false);

  useEffect(() => {
    if (!context.socket || !context.socket.connected) {
      navigate('/game-selector');
      return;
    }

    setLoading(false);

    context.socket.on('room-updated', (data) => {
      setPlayers(data.players);
    });

    return () => {
      context.socket.off('room-updated');
    };
  }, [context.socket, navigate]);

  const handleReady = () => {
    setReadyStatus(!readyStatus);
  };

  const handleStartGame = () => {
    setStartingGame(true);
    setTimeout(() => {
      navigate(`/${gameMode}`);
    }, 1000);
  };

  if (loading) {
    return (
      <div className="lobby-page">
        <div className="loading">Connecting to lobby...</div>
      </div>
    );
  }

  return (
    <div className="lobby-page">
      <header className="lobby-header">
        <div className="lobby-title">
          <h1>Lobby - {gameMode.toUpperCase()}</h1>
          <p>Room ID: {roomId}</p>
        </div>
      </header>

      <div className="lobby-content">
        <section className="players-section">
          <h2>Players in Lobby</h2>
          <div className="players-list">
            {players.map((player) => (
              <div key={player.id} className="player-item">
                <div className="player-avatar">
                  {player.name.charAt(0).toUpperCase()}
                </div>
                <div className="player-info">
                  <p className="player-name">{player.name}</p>
                  <p className="player-joined">Joined {new Date(player.joinedAt).toLocaleTimeString()}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="player-count">{players.length} player{players.length !== 1 ? 's' : ''} ready</p>
        </section>

        <section className="lobby-info">
          <div className="info-card">
            <h3>Game Mode</h3>
            <p>{gameMode}</p>
          </div>
          <div className="info-card">
            <h3>Room Status</h3>
            <p>Waiting for players...</p>
          </div>
        </section>
      </div>

      <footer className="lobby-footer">
        <button
          className={`button ${readyStatus ? 'active' : ''}`}
          onClick={handleReady}
        >
          {readyStatus ? '✓ Ready' : 'Mark Ready'}
        </button>
        <button
          className="button"
          onClick={handleStartGame}
          disabled={startingGame}
        >
          {startingGame ? 'Starting...' : 'Start Game'}
        </button>
        <button
          className="button secondary"
          onClick={() => navigate('/game-selector')}
        >
          Back to Selector
        </button>
      </footer>
    </div>
  );
}

export default Lobby;
