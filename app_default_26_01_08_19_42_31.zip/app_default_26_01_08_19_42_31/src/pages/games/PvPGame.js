import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './PvPGame.css';

function PvPGame({ context }) {
  const navigate = useNavigate();
  const [elo, setElo] = useState(1200);
  const [wins, setWins] = useState(0);
  const [losses, setLosses] = useState(0);
  const [health, setHealth] = useState(100);
  const [enemyHealth, setEnemyHealth] = useState(100);
  const [battleActive, setBattleActive] = useState(false);
  const [battleLog, setBattleLog] = useState([]);
  const [selectedAbility, setSelectedAbility] = useState(null);

  const abilities = [
    { id: 'slash', name: 'Slash', damage: 15, cost: 0, cooldown: 0 },
    { id: 'fireball', name: 'Fireball', damage: 25, cost: 20, cooldown: 2 },
    { id: 'freeze', name: 'Freeze', damage: 10, cost: 30, cooldown: 3 },
    { id: 'heal', name: 'Heal', damage: 0, heal: 30, cost: 25, cooldown: 2 }
  ];

  const startBattle = () => {
    setHealth(100);
    setEnemyHealth(100);
    setBattleActive(true);
    setBattleLog(['Battle started!']);
  };

  const useAbility = (ability) => {
    if (!battleActive) return;

    let newHealth = health;
    let newEnemyHealth = enemyHealth;
    let log = `You used ${ability.name}`;

    if (ability.heal) {
      newHealth = Math.min(100, health + ability.heal);
      log += ` and healed ${ability.heal} HP`;
    } else {
      const damage = ability.damage + Math.random() * 10;
      newEnemyHealth = Math.max(0, enemyHealth - damage);
      log += ` dealing ${damage.toFixed(0)} damage`;
    }

    setBattleLog(prev => [...prev, log]);
    setHealth(newHealth);
    setEnemyHealth(newEnemyHealth);

    // Enemy attack
    setTimeout(() => {
      if (newEnemyHealth > 0) {
        const enemyDamage = 10 + Math.random() * 15;
        const finalHealth = Math.max(0, newHealth - enemyDamage);
        setBattleLog(prev => [...prev, `Enemy attacked you for ${enemyDamage.toFixed(0)} damage`]);
        setHealth(finalHealth);

        if (finalHealth <= 0) {
          endBattle(false);
        }
      } else {
        endBattle(true);
      }
    }, 1000);
  };

  const endBattle = (won) => {
    setBattleActive(false);
    if (won) {
      setWins(prev => prev + 1);
      setElo(prev => prev + 25);
      setBattleLog(prev => [...prev, '✓ Victory! You won the battle!']);
    } else {
      setLosses(prev => prev + 1);
      setElo(prev => Math.max(1000, prev - 15));
      setBattleLog(prev => [...prev, '✗ Defeat! You lost the battle.']);
    }
  };

  const winRate = wins + losses > 0 ? ((wins / (wins + losses)) * 100).toFixed(1) : 0;

  return (
    <div className="game-container pvp-game">
      <header className="game-header">
        <h1>⚔️ PvP Arena</h1>
        <div className="pvp-stats">
          <div className="stat-badge">
            <span className="label">ELO Rating</span>
            <span className="value">{elo}</span>
          </div>
          <div className="stat-badge">
            <span className="label">Win Rate</span>
            <span className="value">{winRate}%</span>
          </div>
        </div>
        <button className="exit-button" onClick={() => navigate('/game-selector')}>
          Exit Game
        </button>
      </header>

      <div className="game-content">
        <section className="battle-section">
          <div className="battle-arena">
            <div className="player-side">
              <div className="character-display">
                  <span className="character-icon">🗡️</span>
                <div className="character-name">You</div>
              </div>
              <div className="health-bar">
                <div className="health-fill" style={{ width: `${health}%` }}></div>
              </div>
              <div className="health-text">{Math.round(health)} / 100 HP</div>
            </div>

            <div className="vs-text">VS</div>

            <div className="enemy-side">
              <div className="character-display">
                <span className="character-icon">👹</span>
                <div className="character-name">Enemy</div>
              </div>
              <div className="health-bar">
                <div className="health-fill" style={{ width: `${enemyHealth}%` }}></div>
              </div>
              <div className="health-text">{Math.round(enemyHealth)} / 100 HP</div>
            </div>
          </div>

          <div className="battle-controls">
            {!battleActive ? (
              <button className="button start-battle" onClick={startBattle}>
                Start Battle
              </button>
            ) : (
              <div className="abilities-grid">
                {abilities.map((ability) => (
                  <button
                    key={ability.id}
                    className="ability-button"
                    onClick={() => useAbility(ability)}
                    disabled={battleActive === false}
                  >
                    <div className="ability-name">{ability.name}</div>
                    {ability.damage > 0 && <div className="ability-stat">DMG: {ability.damage}</div>}
                    {ability.heal && <div className="ability-stat">HEAL: {ability.heal}</div>}
                  </button>
                ))}
              </div>
            )}
          </div>
        </section>

        <section className="stats-section">
          <h3>Battle Statistics</h3>
          <div className="stats-grid">
            <div className="stat-item">
              <label>Wins</label>
              <h2>{wins}</h2>
            </div>
            <div className="stat-item">
              <label>Losses</label>
              <h2>{losses}</h2>
            </div>
            <div className="stat-item">
              <label>Total Battles</label>
              <h2>{wins + losses}</h2>
            </div>
            <div className="stat-item">
              <label>ELO Rating</label>
              <h2>{elo}</h2>
            </div>
          </div>
        </section>

        <section className="battle-log-section">
          <h3>Battle Log</h3>
          <div className="battle-log">
            {battleLog.map((entry, idx) => (
              <div key={idx} className="log-entry">
                {entry}
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

export default PvPGame;
