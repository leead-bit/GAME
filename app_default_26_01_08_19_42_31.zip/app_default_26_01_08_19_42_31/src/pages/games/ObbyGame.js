import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './ObbyGame.css';

function ObbyGame({ context }) {
  const navigate = useNavigate();
  const [currentCheckpoint, setCurrentCheckpoint] = useState(0);
  const [startTime, setStartTime] = useState(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [bestTime, setBestTime] = useState(null);
  const [completions, setCompletions] = useState(0);
  const [progress, setProgress] = useState(0);
  const [running, setRunning] = useState(false);

  const checkpoints = [
    { id: 1, name: 'Start', difficulty: 'Easy' },
    { id: 2, name: 'Wall Jump Platform', difficulty: 'Medium' },
    { id: 3, name: 'Spinning Blades', difficulty: 'Hard' },
    { id: 4, name: 'Moving Platforms', difficulty: 'Hard' },
    { id: 5, name: 'Ice Slide', difficulty: 'Medium' },
    { id: 6, name: 'Lava Jump', difficulty: 'Hard' },
    { id: 7, name: 'Final Jump', difficulty: 'Insane' },
    { id: 8, name: 'Finish', difficulty: 'Easy' }
  ];

  useEffect(() => {
    let interval;
    if (running && startTime) {
      interval = setInterval(() => {
        setElapsedTime((Date.now() - startTime) / 1000);
      }, 10);
    }
    return () => clearInterval(interval);
  }, [running, startTime]);

  const startObby = () => {
    setStartTime(Date.now());
    setRunning(true);
    setCurrentCheckpoint(0);
    setElapsedTime(0);
    setProgress(0);
  };

  const advanceCheckpoint = () => {
    if (currentCheckpoint < checkpoints.length - 1) {
      setCurrentCheckpoint(prev => prev + 1);
      const newProgress = ((currentCheckpoint + 1) / checkpoints.length) * 100;
      setProgress(newProgress);
    } else {
      completeObby();
    }
  };

  const completeObby = () => {
    setRunning(false);
    const finalTime = elapsedTime;
    
    if (!bestTime || finalTime < bestTime) {
      setBestTime(finalTime);
    }
    
    setCompletions(prev => prev + 1);
    setProgress(100);
  };

  const restartObby = () => {
    setCurrentCheckpoint(0);
    setElapsedTime(0);
    setProgress(0);
    setRunning(false);
  };

  return (
    <div className="game-container obby-game">
      <header className="game-header">
        <h1>🧗 Obstacle Course</h1>
        <div className="obby-stats">
          <span>Completions: {completions}</span>
          {bestTime && <span>Best: {bestTime.toFixed(2)}s</span>}
        </div>
        <button className="exit-button" onClick={() => navigate('/game-selector')}>
          Exit Game
        </button>
      </header>

      <div className="game-content">
        <section className="obby-display">
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${progress}%` }}></div>
          </div>
          <p className="progress-text">{Math.round(progress)}% Complete</p>

          <div className="timer">
            <h2>{elapsedTime.toFixed(2)}s</h2>
          </div>

          <div className="checkpoint-display">
            <div className="checkpoint-icon">
              {checkpoints[currentCheckpoint].id === checkpoints.length ? '🏁' : '🧗'}
            </div>
            <div className="checkpoint-info">
              <h3>{checkpoints[currentCheckpoint].name}</h3>
              <p>Checkpoint {currentCheckpoint + 1} / {checkpoints.length}</p>
              <span className={`difficulty ${checkpoints[currentCheckpoint].difficulty.toLowerCase()}`}>
                {checkpoints[currentCheckpoint].difficulty}
              </span>
            </div>
          </div>

          {!running && currentCheckpoint === 0 ? (
            <button className="button start-button" onClick={startObby}>
              Start Course
            </button>
          ) : running ? (
            <button className="button next-button" onClick={advanceCheckpoint}>
              Next Checkpoint
            </button>
          ) : (
            <>
              <div className="completion-message">✓ Course Completed!</div>
              <button className="button restart-button" onClick={restartObby}>
                Run Again
              </button>
            </>
          )}
        </section>

        <section className="checkpoints-list">
          <h3>Checkpoints</h3>
          <div className="checkpoints">
            {checkpoints.map((checkpoint, idx) => (
              <div
                key={checkpoint.id}
                className={`checkpoint-item ${idx === currentCheckpoint ? 'active' : ''} ${idx < currentCheckpoint ? 'completed' : ''}`}
              >
                <div className="checkpoint-number">{checkpoint.id}</div>
                <div className="checkpoint-details">
                  <h4>{checkpoint.name}</h4>
                  <p>{checkpoint.difficulty}</p>
                </div>
                {idx < currentCheckpoint && <span className="checkmark">✓</span>}
                {idx === currentCheckpoint && <span className="current">▶</span>}
              </div>
            ))}
          </div>
        </section>

        <section className="tips-section">
          <h3>Tips</h3>
          <div className="tips-list">
            <div className="tip">
              <span className="tip-icon">⏱️</span>
              <p>Complete courses faster to improve your best time</p>
            </div>
            <div className="tip">
              <span className="tip-icon">🎯</span>
              <p>Each checkpoint is harder than the previous one</p>
            </div>
            <div className="tip">
              <span className="tip-icon">🏆</span>
              <p>Complete courses to earn achievements</p>
            </div>
            <div className="tip">
              <span className="tip-icon">📊</span>
              <p>Your best time is saved and displayed</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

export default ObbyGame;
