import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './RacingGame.css';

function RacingGame({ context }) {
  const navigate = useNavigate();
  const [coins, setCoins] = useState(0);
  const [selectedCar, setSelectedCar] = useState('basic');
  const [raceTime, setRaceTime] = useState(0);
  const [raceActive, setRaceActive] = useState(false);
  const [bestTime, setBestTime] = useState(null);
  const [carUpgrades, setCarUpgrades] = useState({
    speed: 1,
    acceleration: 1,
    handling: 1
  });
  const [records, setRecords] = useState([]);

  const cars = {
    basic: { name: 'Basic Car', speed: 100, cost: 0, color: '#888' },
    sports: { name: 'Sports Car', speed: 150, cost: 5000, color: '#ff0000' },
    supercar: { name: 'Supercar', speed: 200, cost: 20000, color: '#ffd700' }
  };

  useEffect(() => {
    let interval;
    if (raceActive) {
      interval = setInterval(() => {
        setRaceTime(prev => prev + 0.01);
      }, 10);
    }
    return () => clearInterval(interval);
  }, [raceActive]);

  const startRace = () => {
    setRaceActive(true);
    setRaceTime(0);
  };

  const finishRace = () => {
    setRaceActive(false);
    const finalTime = parseFloat(raceTime.toFixed(2));
    
    if (!bestTime || finalTime < bestTime) {
      setBestTime(finalTime);
    }

    const newRecord = {
      car: selectedCar,
      time: finalTime,
      timestamp: new Date().toLocaleTimeString(),
      speed: cars[selectedCar].speed * carUpgrades.speed
    };

    setRecords(prev => [...prev.slice(-9), newRecord]);
    setCoins(prev => prev + Math.floor(1000 / finalTime));
  };

  const handleUpgrade = (upgrade) => {
    const cost = 1000 * carUpgrades[upgrade];
    if (coins >= cost) {
      setCoins(prev => prev - cost);
      setCarUpgrades(prev => ({
        ...prev,
        [upgrade]: prev[upgrade] + 0.1
      }));
    }
  };

  const handleBuyCar = (carKey) => {
    const car = cars[carKey];
    if (coins >= car.cost && car.cost > 0) {
      setCoins(prev => prev - car.cost);
      setSelectedCar(carKey);
    }
  };

  return (
    <div className="game-container racing-game">
      <header className="game-header">
        <h1>🏎️ Racing Game</h1>
        <div className="race-coins">Coins: {coins.toLocaleString()}</div>
        <button className="exit-button" onClick={() => navigate('/game-selector')}>
          Exit Game
        </button>
      </header>

      <div className="game-content">
        <section className="race-section">
          <div className="race-display">
            <div className="car-visual">
              <div className="car" style={{ color: cars[selectedCar].color }}>
                🏎️
              </div>
            </div>
            <div className="race-stats">
              <div className="race-stat">
                <label>Current Car</label>
                <h3>{cars[selectedCar].name}</h3>
              </div>
              <div className="race-stat">
                <label>Speed</label>
                <h3>{Math.round(cars[selectedCar].speed * carUpgrades.speed)}</h3>
              </div>
              {bestTime && (
                <div className="race-stat">
                  <label>Best Time</label>
                  <h3>{bestTime.toFixed(2)}s</h3>
                </div>
              )}
            </div>
          </div>

          <div className="race-controls">
            {!raceActive ? (
              <button className="button start-race" onClick={startRace}>
                Start Race
              </button>
            ) : (
              <>
                <div className="race-timer">{raceTime.toFixed(2)}s</div>
                <button className="button finish-race" onClick={finishRace}>
                  Finish Race
                </button>
              </>
            )}
          </div>
        </section>

        <section className="upgrades-section">
          <h3>Car Upgrades</h3>
          <div className="upgrades-list">
            {Object.entries(carUpgrades).map(([key, value]) => (
              <div key={key} className="upgrade-item">
                <div className="upgrade-info">
                  <label>{key.charAt(0).toUpperCase() + key.slice(1)}</label>
                  <p>{(value * 100).toFixed(0)}%</p>
                </div>
                <button
                  className="button"
                  onClick={() => handleUpgrade(key)}
                  disabled={coins < 1000 * value}
                >
                  Upgrade ({Math.round(1000 * value)} coins)
                </button>
              </div>
            ))}
          </div>
        </section>

        <section className="cars-section">
          <h3>Available Cars</h3>
          <div className="cars-grid">
            {Object.entries(cars).map(([key, car]) => (
              <div key={key} className={`car-card ${selectedCar === key ? 'selected' : ''}`}>
                <div className="car-icon">🏎️</div>
                <h4>{car.name}</h4>
                <p className="car-speed">Speed: {car.speed}</p>
                <button
                  className="button"
                  onClick={() => handleBuyCar(key)}
                  disabled={coins < car.cost || selectedCar === key}
                >
                  {selectedCar === key ? 'Owned' : car.cost === 0 ? 'Equipped' : `Buy ${car.cost}`}
                </button>
              </div>
            ))}
          </div>
        </section>

        <section className="records-section">
          <h3>Recent Records</h3>
          <div className="records-list">
            {records.length === 0 ? (
              <p className="no-records">No races completed yet</p>
            ) : (
              records.map((record, idx) => (
                <div key={idx} className="record-item">
                  <span>{record.car}</span>
                  <span>{record.time}s</span>
                  <span>{record.timestamp}</span>
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </div>
  );
}

export default RacingGame;
