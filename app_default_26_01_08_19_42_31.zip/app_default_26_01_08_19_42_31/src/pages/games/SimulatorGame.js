import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './SimulatorGame.css';

function SimulatorGame({ context }) {
  const navigate = useNavigate();
  const [currency, setCurrency] = useState(0);
  const [clickPower, setClickPower] = useState(1);
  const [autoClickers, setAutoClickers] = useState(0);
  const [prestige, setPrestige] = useState(0);
  const [totalClicks, setTotalClicks] = useState(0);
  const [prestigeMultiplier, setPrestigeMultiplier] = useState(1);
  const [upgrades, setUpgrades] = useState({
    doubleCurrency: { level: 0, cost: 100 },
    clickBoost: { level: 0, cost: 150 },
    autoClicker: { level: 0, cost: 500 }
  });

  useEffect(() => {
    const autoClickerInterval = setInterval(() => {
      setCurrency(prev => prev + (autoClickers * prestigeMultiplier));
    }, 1000);

    return () => clearInterval(autoClickerInterval);
  }, [autoClickers, prestigeMultiplier]);

  useEffect(() => {
    const saveInterval = setInterval(() => {
      if (context.socket) {
        context.socket.emit('save-game-data', {
          gameMode: 'simulator',
          data: {
            currency,
            clickPower,
            autoClickers,
            prestige,
            totalClicks,
            prestigeMultiplier,
            upgrades
          }
        });
      }
    }, 5000);

    return () => clearInterval(saveInterval);
  }, [currency, clickPower, autoClickers, prestige, totalClicks, prestigeMultiplier, upgrades, context.socket]);

  const handleClick = () => {
    const gained = clickPower * prestigeMultiplier;
    setCurrency(prev => prev + gained);
    setTotalClicks(prev => prev + 1);
  };

  const handleBuyUpgrade = (upgradeKey) => {
    const upgrade = upgrades[upgradeKey];
    if (currency >= upgrade.cost) {
      setCurrency(prev => prev - upgrade.cost);
      setUpgrades(prev => ({
        ...prev,
        [upgradeKey]: {
          ...prev[upgradeKey],
          level: prev[upgradeKey].level + 1,
          cost: Math.ceil(prev[upgradeKey].cost * 1.15)
        }
      }));

      if (upgradeKey === 'clickBoost') {
        setClickPower(prev => prev + 1);
      } else if (upgradeKey === 'autoClicker') {
        setAutoClickers(prev => prev + 1);
      } else if (upgradeKey === 'doubleCurrency') {
        setPrestigeMultiplier(prev => prev * 1.5);
      }
    }
  };

  const handlePrestige = () => {
    if (currency >= 10000) {
      const prestigeGain = Math.floor(Math.sqrt(totalClicks / 1000));
      setPrestige(prev => prev + prestigeGain);
      setCurrency(0);
      setClickPower(1 + prestige * 0.1);
      setAutoClickers(0);
      setTotalClicks(0);
      setPrestigeMultiplier(1 + prestige * 0.05);
    }
  };

  return (
    <div className="game-container simulator-game">
      <header className="game-header">
        <h1>Idle Simulator</h1>
        <button className="exit-button" onClick={() => navigate('/game-selector')}>
          Exit Game
        </button>
      </header>

      <div className="game-content">
        <section className="stats-section">
          <div className="stat-card">
            <label>Total Currency</label>
            <h2>{Math.floor(currency).toLocaleString()}</h2>
          </div>
          <div className="stat-card">
            <label>Click Power</label>
            <h3>{clickPower.toFixed(1)} per click</h3>
          </div>
          <div className="stat-card">
            <label>Auto Clickers</label>
            <h3>{autoClickers} active</h3>
          </div>
          <div className="stat-card">
            <label>Prestige Level</label>
            <h3>{prestige}</h3>
          </div>
          <div className="stat-card">
            <label>Total Clicks</label>
            <h3>{totalClicks.toLocaleString()}</h3>
          </div>
        </section>

        <section className="click-section">
          <button className="click-button" onClick={handleClick}>
            <div className="click-icon">💰</div>
            <div className="click-text">Click!</div>
            <div className="click-gain">+{(clickPower * prestigeMultiplier).toFixed(1)}</div>
          </button>
        </section>

        <section className="upgrades-section">
          <h3>Upgrades</h3>
          <div className="upgrades-grid">
            {Object.entries(upgrades).map(([key, upgrade]) => (
              <div key={key} className="upgrade-card">
                <div className="upgrade-header">
                  <h4>{key === 'clickBoost' ? 'Click Boost' : key === 'autoClicker' ? 'Auto Clicker' : 'Double Currency'}</h4>
                  <span className="upgrade-level">Level {upgrade.level}</span>
                </div>
                <p className="upgrade-description">
                  {key === 'clickBoost' && 'Increase click power by 1'}
                  {key === 'autoClicker' && 'Earn currency automatically'}
                  {key === 'doubleCurrency' && 'Increase all earnings by 50%'}
                </p>
                <button
                  className="button"
                  onClick={() => handleBuyUpgrade(key)}
                  disabled={currency < upgrade.cost}
                >
                  Cost: {upgrade.cost}
                </button>
              </div>
            ))}
          </div>
        </section>

        <section className="prestige-section">
          <div className="prestige-card">
            <h3>Prestige System</h3>
            <p>Reset your progress to gain prestige level and permanent multipliers</p>
            <p className="prestige-info">
              Required: 10,000 currency
              <br />
              You will gain: {Math.floor(Math.sqrt(totalClicks / 1000))} prestige level
            </p>
            <button
              className="button"
              onClick={handlePrestige}
              disabled={currency < 10000}
            >
              Prestige Now
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}

export default SimulatorGame;
