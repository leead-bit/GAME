import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import io from 'socket.io-client';
import './App.css';

import Home from './pages/Home';
import GameSelector from './pages/GameSelector';
import SimulatorGame from './pages/games/SimulatorGame';
import RacingGame from './pages/games/RacingGame';
import ObbyGame from './pages/games/ObbyGame';
import PvPGame from './pages/games/PvPGame';
import Lobby from './pages/Lobby';

const SOCKET_SERVER = process.env.REACT_APP_WS_URL || 'http://localhost:5000';

function App() {
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);
  const [currentRoom, setCurrentRoom] = useState(null);
  const [playerName, setPlayerName] = useState(localStorage.getItem('playerName') || 'Guest');

  useEffect(() => {
    const newSocket = io(SOCKET_SERVER, {
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 5
    });

    newSocket.on('connect', () => {
      console.log('Connected to server');
      setConnected(true);
    });

    newSocket.on('disconnect', () => {
      console.log('Disconnected from server');
      setConnected(false);
    });

    newSocket.on('join-success', (data) => {
      setCurrentRoom(data);
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, []);

  const handleSetPlayerName = (name) => {
    setPlayerName(name);
    localStorage.setItem('playerName', name);
  };

  const contextValue = {
    socket,
    connected,
    currentRoom,
    setCurrentRoom,
    playerName,
    setPlayerName: handleSetPlayerName
  };

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/game-selector" element={<GameSelector context={contextValue} />} />
        <Route path="/lobby/:gameMode/:roomId" element={<Lobby context={contextValue} />} />
        <Route path="/simulator" element={<SimulatorGame context={contextValue} />} />
        <Route path="/racing" element={<RacingGame context={contextValue} />} />
        <Route path="/obby" element={<ObbyGame context={contextValue} />} />
        <Route path="/pvp" element={<PvPGame context={contextValue} />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}

export default App;
