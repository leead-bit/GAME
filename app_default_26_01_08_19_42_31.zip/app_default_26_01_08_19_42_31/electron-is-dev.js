module.exports = process.mainModule.filename.includes('app.asar') === false;
