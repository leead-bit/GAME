const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Serve static files from build directory
const buildPath = path.join(__dirname, '../build');
app.use(express.static(buildPath));

// Game state management
const gameState = {
  rooms: {},
  players: {},
  scores: {},
  gameData: {
    simulatorMode: {
      currency: 0,
      upgrades: {},
      prestige: 0
    },
    racingMode: {
      records: [],
      carUpgrades: {},
      coins: 0
    },
    obbyMode: {
      checkpoints: [],
      bestTime: null,
      completed: false
    },
    pvpMode: {
      elo: 1200,
      wins: 0,
      losses: 0
    }
  }
};

// Create or join room
io.on('connection', (socket) => {
  console.log(`Player connected: ${socket.id}`);

  socket.on('join-game', (data) => {
    const { gameMode, roomId, playerName } = data;
    const actualRoomId = roomId || uuidv4();

    if (!gameState.rooms[actualRoomId]) {
      gameState.rooms[actualRoomId] = {
        id: actualRoomId,
        gameMode,
        players: [],
        started: false,
        gameState: {},
        createdAt: new Date()
      };
    }

    const room = gameState.rooms[actualRoomId];
    room.players.push({
      id: socket.id,
      name: playerName || `Player${Math.floor(Math.random() * 1000)}`,
      joinedAt: new Date()
    });

    socket.join(actualRoomId);
    gameState.players[socket.id] = {
      name: playerName || `Player${Math.floor(Math.random() * 1000)}`,
      roomId: actualRoomId,
      gameMode,
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 }
    };

    io.to(actualRoomId).emit('room-updated', {
      roomId: actualRoomId,
      players: room.players,
      gameMode
    });

    socket.emit('join-success', {
      roomId: actualRoomId,
      playerId: socket.id,
      gameMode
    });

    console.log(`Player ${socket.id} joined room ${actualRoomId}`);
  });

  socket.on('player-move', (data) => {
    const { roomId, position, rotation } = data;
    if (gameState.players[socket.id]) {
      gameState.players[socket.id].position = position;
      gameState.players[socket.id].rotation = rotation;
      io.to(roomId).emit('player-moved', {
        playerId: socket.id,
        position,
        rotation
      });
    }
  });

  socket.on('game-action', (data) => {
    const { roomId, action, payload } = data;
    io.to(roomId).emit('action-broadcast', {
      playerId: socket.id,
      action,
      payload
    });
  });

  socket.on('chat-message', (data) => {
    const { roomId, message } = data;
    const player = gameState.players[socket.id];
    if (player) {
      io.to(roomId).emit('chat-received', {
        playerId: socket.id,
        playerName: player.name,
        message,
        timestamp: new Date()
      });
    }
  });

  socket.on('update-score', (data) => {
    const { roomId, score, gameMode } = data;
    if (!gameState.scores[roomId]) {
      gameState.scores[roomId] = [];
    }
    gameState.scores[roomId].push({
      playerId: socket.id,
      playerName: gameState.players[socket.id]?.name || 'Unknown',
      score,
      gameMode,
      timestamp: new Date()
    });
    io.to(roomId).emit('scores-updated', gameState.scores[roomId]);
  });

  socket.on('save-game-data', (data) => {
    const { gameMode, data: gameData } = data;
    if (gameState.gameData[gameMode]) {
      gameState.gameData[gameMode] = {
        ...gameState.gameData[gameMode],
        ...gameData
      };
    }
    socket.emit('game-data-saved', { success: true });
  });

  socket.on('get-game-data', (data) => {
    const { gameMode } = data;
    socket.emit('game-data-retrieved', {
      gameMode,
      data: gameState.gameData[gameMode] || {}
    });
  });

  socket.on('disconnect', () => {
    const player = gameState.players[socket.id];
    if (player) {
      const room = gameState.rooms[player.roomId];
      if (room) {
        room.players = room.players.filter(p => p.id !== socket.id);
        io.to(player.roomId).emit('player-disconnected', {
          playerId: socket.id
        });
        if (room.players.length === 0) {
          delete gameState.rooms[player.roomId];
        }
      }
      delete gameState.players[socket.id];
    }
    console.log(`Player disconnected: ${socket.id}`);
  });
});

// API endpoints
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date() });
});

app.get('/api/game-modes', (req, res) => {
  res.json({
    modes: [
      {
        id: 'simulator',
        name: 'Idle Simulator',
        description: 'Earn currency and upgrade your abilities',
        players: 0,
        maxPlayers: 50
      },
      {
        id: 'racing',
        name: 'Racing',
        description: 'Race against other players on exciting tracks',
        players: 0,
        maxPlayers: 12
      },
      {
        id: 'obby',
        name: 'Obstacle Course',
        description: 'Complete challenging parkour courses',
        players: 0,
        maxPlayers: 20
      },
      {
        id: 'pvp',
        name: 'PvP Arena',
        description: 'Battle other players in intense combat',
        players: 0,
        maxPlayers: 16
      }
    ]
  });
});

app.get('/api/rooms', (req, res) => {
  const rooms = Object.values(gameState.rooms).map(room => ({
    id: room.id,
    gameMode: room.gameMode,
    playerCount: room.players.length,
    players: room.players,
    createdAt: room.createdAt
  }));
  res.json({ rooms });
});

app.post('/api/create-room', (req, res) => {
  const { gameMode } = req.body;
  const roomId = uuidv4();
  gameState.rooms[roomId] = {
    id: roomId,
    gameMode,
    players: [],
    started: false,
    gameState: {},
    createdAt: new Date()
  };
  res.json({ roomId, success: true });
});

// Serve React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(buildPath, 'index.html'));
});

server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
  console.log(`WebSocket server running on ws://localhost:${PORT}`);
});

process.on('SIGINT', () => {
  console.log('Server shutting down...');
  server.close();
  process.exit(0);
});
