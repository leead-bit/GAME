# Roblox Like - Multiplayer Game Platform

A complete, production-ready Roblox-like multiplayer game platform built with Electron, React, Three.js, and WebSocket. Play 4 exciting game modes with friends and climb the leaderboards.

## Features

### 🎮 4 Game Modes
1. **Idle Simulator** - Earn currency, upgrade abilities, and unlock the prestige system
2. **Racing** - Race against players on tracks with car upgrades and speed records
3. **Obstacle Course** - Complete parkour challenges and beat leaderboard times
4. **PvP Arena** - Battle other players, gain ELO rating, and climb the competitive ladder

### 🌟 Core Features
- ✅ **Multiplayer Support** - Real-time WebSocket-based multiplayer with Socket.io
- ✅ **Persistent Progress** - All game data saved automatically
- ✅ **Leaderboards** - Track scores and rankings
- ✅ **One-Click Launch** - Click the executable to play immediately
- ✅ **Cross-Platform** - Works on Windows, Mac, and Linux
- ✅ **Auto-Update** - Game updates check on startup
- ✅ **No Dependencies** - All assets and servers bundled together

## Prerequisites

### Required Software
- **Node.js** (v14 or higher) - [Download](https://nodejs.org/)
- **npm** (comes with Node.js)
- **Git** (optional, for cloning)

### System Requirements
- **Windows**: Windows 7 or later (64-bit)
- **Mac**: macOS 10.12 or later
- **Linux**: Ubuntu 18.04 or later

### Storage Requirements
- **Disk Space**: ~500 MB for installation
- **RAM**: Minimum 2 GB (recommended 4 GB+)

## Installation

### Step 1: Clone or Download the Repository
